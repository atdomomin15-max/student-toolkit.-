const $ = (id) => document.getElementById(id);

// Mobile navigation
const menuBtn = $("menuBtn");
const navLinks = $("navLinks");

menuBtn.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

navLinks.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => navLinks.classList.remove("open"));
});

// Percentage calculator
$("percentBtn").addEventListener("click", () => {
  const value = Number($("percentValue").value);
  const total = Number($("percentTotal").value);
  const result = $("percentResult");

  if (!Number.isFinite(value) || !Number.isFinite(total) || total <= 0) {
    result.textContent = "Please enter valid numbers.";
    return;
  }

  result.textContent = `${((value / total) * 100).toFixed(2)}%`;
});

// Grade calculator
$("gradeBtn").addEventListener("click", () => {
  const obtained = Number($("gradeObtained").value);
  const total = Number($("gradeTotal").value);
  const result = $("gradeResult");

  if (!Number.isFinite(obtained) || !Number.isFinite(total) || total <= 0 || obtained < 0 || obtained > total) {
    result.textContent = "Enter marks between 0 and the maximum marks.";
    return;
  }

  const percentage = (obtained / total) * 100;
  let grade;

  if (percentage >= 90) grade = "A+";
  else if (percentage >= 80) grade = "A";
  else if (percentage >= 70) grade = "B";
  else if (percentage >= 60) grade = "C";
  else if (percentage >= 50) grade = "D";
  else grade = "F";

  result.textContent = `${percentage.toFixed(2)}% — Grade ${grade}`;
});

// Study timer
let remaining = 25 * 60;
let timerId = null;

function renderTimer() {
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  $("timerDisplay").textContent =
    `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

$("startTimer").addEventListener("click", () => {
  if (timerId !== null) return;

  timerId = setInterval(() => {
    if (remaining <= 0) {
      clearInterval(timerId);
      timerId = null;
      alert("Study session complete! 🎉");
      return;
    }

    remaining--;
    renderTimer();
  }, 1000);
});

$("pauseTimer").addEventListener("click", () => {
  clearInterval(timerId);
  timerId = null;
});

$("resetTimer").addEventListener("click", () => {
  clearInterval(timerId);
  timerId = null;
  remaining = 25 * 60;
  renderTimer();
});

// Unit converter
const unitToMeters = {
  m: 1,
  km: 1000,
  cm: 0.01,
  ft: 0.3048,
  in: 0.0254
};

$("convertBtn").addEventListener("click", () => {
  const value = Number($("unitValue").value);
  const from = $("fromUnit").value;
  const to = $("toUnit").value;
  const result = $("convertResult");

  if (!Number.isFinite(value)) {
    result.textContent = "Please enter a number.";
    return;
  }

  const meters = value * unitToMeters[from];
  const converted = meters / unitToMeters[to];

  result.textContent = `${value} ${from} = ${converted.toLocaleString(undefined, {
    maximumFractionDigits: 8
  })} ${to}`;
});

// Age calculator
$("ageBtn").addEventListener("click", () => {
  const input = $("birthDate").value;
  const result = $("ageResult");

  if (!input) {
    result.textContent = "Please select your birth date.";
    return;
  }

  const birth = new Date(`${input}T00:00:00`);
  const today = new Date();

  if (birth > today) {
    result.textContent = "Birth date cannot be in the future.";
    return;
  }

  let years = today.getFullYear() - birth.getFullYear();
  let months = today.getMonth() - birth.getMonth();

  if (today.getDate() < birth.getDate()) months--;

  if (months < 0) {
    years--;
    months += 12;
  }

  result.textContent = `${years} year${years === 1 ? "" : "s"} and ${months} month${months === 1 ? "" : "s"} old`;
});

$("year").textContent = new Date().getFullYear();
renderTimer();
